import React, { Component } from 'react'

export default class Carousel extends Component {
    render() {
        return (
            <div>
            <div className="indicatorsr"> </div>
            <div className="indicators1r"> </div>
            <div className="indicators2r"> </div>
            <div className="indicators3r"> </div> 
            </div>
        )
    }
}
