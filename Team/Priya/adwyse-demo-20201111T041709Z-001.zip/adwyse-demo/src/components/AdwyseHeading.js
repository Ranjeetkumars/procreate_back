import React, { Component } from 'react'

export default class AdwyseHeading extends Component {
    render() {
        return (
            <div>
            <div style={{marginTop:"41px",marginLeft:"-5px"}} className="backArrow">
            </div>
            <div className="headingLogo" style={{marginTop:"12px",width:"414px",width:"212px",margin:"auto",marginLeft:"57px"}}>
            </div> 
            </div>
        )
    }
}