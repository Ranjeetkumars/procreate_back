import React, { Component } from 'react'
import '../App.css';

  export default class  TermsConditions extends Component {
      render() {
          return (
              <div>
        <form className="form">
  
        <a href="#" Back Arrow class="backArrowAboutUs"></a>
  <h3 style={{marginTop: "41px",    marginLeft: "56px",color:"Black"}}>Terms & Conditions</h3>
           <label>
  
          </label>
          <div>
         </div>
  
        <p >These terms and conditions outline the rules and regulations for the use of Adwyse’s App, located at Playstore or AppStore</p>
  <p style={{marginTop: "48px",    marginLeft: "36px",width:"56px",height:"19px",font:"var(--unnamed-font-style-normal) normal var(--unnamed-font-weight-bold) var(--unnamed-font-size-16)/var(--unnamed-line-spacing-19) var(--unnamed-font-family-lato);letter-spacing: var(--unnamed-character-spacing-0)",color:"var(--primary-blue)",textAlign:"left",font:"normal normal bold 16px/19px Lato",letterSpacing:"0px",color:"#2D5795",opacity: "1"}}>General</p>



  <div>
  <p style={{marginTop: "-3px",    marginLeft: "45px",width:"341px",height:"266px",font:"var(--unnamed-font-style-normal) normal var(--unnamed-font-weight-normal) var(--unnamed-font-size-16)/var(--unnamed-line-spacing-19) var(--unnamed-font-family-lato);letter-spacing: var(--unnamed-character-spacing-0)",color:"var(--dark-gray)",textAlign:"left",font:"normal normal normal 16px/19px Lato",letterSpacing:"0px",color:"#4A5058",opacity: "1"}}>By accessing this website we assume you accept these terms and conditions. Do not continue to use adwyse.com if you do not agree to take all of the terms and conditions stated on this page. <br></br><br></br>The following terminology applies to these Terms and Conditions, Privacy Statement and Disclaimer Notice and all Agreements: “Client”, “You” and “Your” refers to you, the person log on this website and compliant to the Company’s terms and conditions. “The Company”, “Ourselves”, “We”, “Our” and “Us”, refers to our Company. “Party”, “Parties”, or “Us”, refers to both the Client and ourselves.</p>

  </div>
    
       <div>

       <p style={{marginTop: "-2px",    marginLeft: "42px",width:"56px",height:"19px",font:"var(--unnamed-font-style-normal) normal var(--unnamed-font-weight-bold) var(--unnamed-font-size-16)/var(--unnamed-line-spacing-19) var(--unnamed-font-family-lato);letter-spacing: var(--unnamed-character-spacing-0)",color:"var(--primary-blue)",textAlign:"left",font:"normal normal bold 16px/19px Lato",letterSpacing:"0px",color:"#2D5795",opacity: "1"}}>Payment</p>









         <p style={{marginTop: "-3px",    marginLeft: "45px",width:"341px",height:"247px",font:"var(--unnamed-font-style-normal) normal var(--unnamed-font-weight-normal) var(--unnamed-font-size-16)/var(--unnamed-line-spacing-19) var(--unnamed-font-family-lato);letter-spacing: var(--unnamed-character-spacing-0)",color:" var(--dark-gray)",textAlign:"left",font:"normal normal normal 16px/19px Lato",letterSpacing:"0px",color:"#4A5058",opacity: "1"}} >All terms refer to the offer, acceptance and consideration of payment necessary to undertake the process of our assistance to the Client in the most appropriate manner for the express purpose of meeting the Client’s needs in respect of provision of the Company’s stated services, in accordance with and subject to, prevailing law of Netherlands.<br></br><br></br> Any use of the above terminology or other words in the singular, plural, capitalization and/or he/she or they, are taken as interchangeable and therefore as referring to same.</p>
     </div>
     
        </form>
      </div>
          )
      }
  }
