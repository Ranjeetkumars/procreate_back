import React from 'react';
import Login from './screens/login';
import Specialization from './screens/Specialization';
import SpecializationSelected from './screens/SpecializationSelected';
import SpecializationConform from './screens/SpecializationConform';
import ProfilePreview from './screens/ProfilePreview';
import OngoingSwipeup from './screens/OngoingSwipup';
import Settings from './screens/Settings';

function App() {
  return (
    <div>

 {/* <Login/> */}

   {/* <Specialization/> */}
   
 {/* <SpecializationSelected/> */}

 {/* <SpecializationConform/> */}

  {/* <ProfilePreview/>  */}
 
  {/* <OngoingSwipeup/>  */}

  <Settings/> 
 
    </div>
  );
}

export default App;
