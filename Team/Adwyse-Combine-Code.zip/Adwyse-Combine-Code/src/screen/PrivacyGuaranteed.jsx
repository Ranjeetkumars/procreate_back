import React, { Component } from 'react'
import '../App.css';
import '../assets/css/PrivacyGuaranteed.css';

export default class  PrivacyGuaranteed extends Component {
    render() {
        return (
            <div>
      <form className="form">
        <a href="#" className="backArrow1">
        </a>
     <a href="#" className="skip">
                Skip
        </a>
        <div>
      </div>
      <div className="privacyGuaranteedLog">

       </div>

   <h3><b style={{marginLeft:"-55px"}}>PrivacyGuaranteed!</b></h3>
      <p style={{marginLeft:"37px",width:"337",height:"47px",font:"var(--unnamed-font-style-normal) normal var(--unnamed-font-weight-normal) 18px/25px var(--unnamed-font-family-lato)",color:"var(--dark-gray)",textAlign:"left",font:"normal normal normal 18px/25px Lato",color: "#4a5058", opacity: 1}}>All your patient records & medical history in one place, safe & secure.</p>
        <div>
          <label />
      
          <button  style={{marginLeft:"37px",width:"345px",height:"50px",background:"var(--green) 0% 0% no-repeat padding-box",background:"#2eb9ae 0% 0% no-repeat padding-box",borderRadius:"6px",opacity:"1",color: "white"}}><span class="span">Next</span>
          <div className="forwardArrow"></div>
          </button>
          <br></br>
          <div className="smallrectangle">
       <div   className="rectangle" > 
      <div   className="smallrectangle2"  >
               <div   className="smallrectangle2"  > </div>
          </div>  </div> </div>
       </div> 
      </form>
    </div>
        )
    }
}
