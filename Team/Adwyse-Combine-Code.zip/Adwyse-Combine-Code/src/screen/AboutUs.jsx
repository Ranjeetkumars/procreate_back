import React, { Component } from 'react'
import '../App.css';
import '../assets/css/AboutUs.css';

export default class  AboutUs extends Component {
    render() {
        return (
            <div>
      <form className="form">

      <a href="#" Back Arrow class="backArrowAboutUs"></a>
<h3 class="hpar" style={{marginTop: "41px",    marginLeft: "56px",color:"Black"}}>About Us</h3>
         <label>

        </label>
        <div>
       </div>
       <div className="headingLogo" style={{marginTop:"12px",marginLeft:"34px",width:"201px"}}></div>

      <p style={{marginTopop: "225px",marginLeft:"36px",width:"241px",height:"19px",font:"var(--unnamed-font-style-normal) normal var(--unnamed-font-weight-bold) var(--unnamed-font-size-16)/var(--unnamed-line-spacing-19) var(--unnamed-font-family-lato)",letterSpacing:"var(--unnamed-character-spacing-0)",color:"var(--primary-blue)",textAlign:"left",font:"normal normal bold 16px/19px Lato",letterSpacing:"0",color:"#2D5795",opacity:"1"}} >Connecting doctors with patients!</p>

<br></br>
<div>
<p className="par">Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.</p>
</div>
       <br></br>
       <br></br>
       <br></br>
       <br></br>
       <br></br>
       <br></br>
       <div>
{/*        <p className="par">Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.</p>
 */}   </div>
   <div className="aboutUs" >
        </div>
      </form>
    </div>
        )
    }
}
