import React, { useState } from 'react';
import { makeStyles } from '@material-ui/core/styles';
import List from '@material-ui/core/List';
import ListItem from '@material-ui/core/ListItem';
import ListItemIcon from '@material-ui/core/ListItemIcon';
import ListItemText from '@material-ui/core/ListItemText';
import { Button } from '@material-ui/core';
//import StarIcon from '@material-ui/icons/Star';

const useStyles = makeStyles((theme) => ({
  root: {
    width: '100%',
    maxWidth: 360,
    backgroundColor: theme.palette.background.paper,
  },
}));

export default function InsetList() {
  const {color,setColor}=useState('red')
 const classes = useStyles();
 const demo =() =>{
   alert("demo");
 }

 const handleClick=() => {
   alert("hello");
 }

  return (
    <List component="nav" className={classes.root} aria-label="contacts">
      <ListItem button>
        <ListItemIcon>
         <div>hi</div>
        </ListItemIcon>
        <ListItemText primary="Chelsea Otakan" />
      </ListItem>
      <ListItem style={{color:color}} button onClick={()=>handleClick()}>
        <ListItemText inset primary="Eric Hoffman" onClick={demo()} />
      </ListItem>
    </List>
  );
}