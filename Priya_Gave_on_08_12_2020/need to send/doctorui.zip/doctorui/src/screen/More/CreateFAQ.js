import React, { Component } from 'react'

import SVGImages from '../../components/icons';
import '../../assets/css/confirmation.css';
import '../../assets/css/dropDown.css';
import { Dropdown } from 'primereact/dropdown';

import '../../App.css';
import { InputTextarea } from 'primereact/inputtextarea';
import { Button } from 'primereact/button';



import dr from "../../components/dr";

export default class Conformation extends Component {
  constructor(props) {
    super(props);
    this.state = {
      selectedCity2: null,
      value1: "",
      value2: "",
    };
    

    this.cities = [
      { name: "New York", code: "NY" },
      { name: "Rome", code: "RM" },
      { name: "London", code: "LDN" },
      { name: "Istanbul", code: "IST" },
      { name: "Paris", code: "PRS" },
    ];
    this.onCityChange2 = this.onCityChange2.bind(this);
  }
  onCityChange2(e) {
    this.setState({ selectedCity2: e.value });
  }
  render() {
    return (
      <div>
        <form className="card">

          <br></br>

          <div className="Myblogback"><h2 >FAQ's</h2></div>

          <h3 style={h3}>

            Add a Question</h3>



          <p style={p}>Ask us any question and we will<br></br> get back to you in no time.</p><br></br><br></br>
          <label htmlFor="username1"
            className="p-d-block"
            style={label}>Query Topic
          </label>
<dr/><br></br><br></br>

          <div className="dropdown-demo">
            <Dropdown
              value={this.state.selectedCity2}
              options={this.cities}
              onChange={this.onCityChange2}
              optionLabel="name"
              editable
            />
          </div><br></br>





         <InputTextarea placeholder="Type your question here…" style={textarea} value={this.state.value2} onChange={(e) => this.setState({value2: e.target.value})} rows={5} cols={30} autoResize />





          <br></br>


          <Button
          variant="contained"
          color="primary"
          style={{
            backgroundColor: "#2EB9AE",
            width: "351px",
            height: "50px",
            margin: "auto",
            marginBottom: "26px",
            marginLeft: "-0px",
            color:"white",
            marginLeft:'10PX',
background: "var(--green) 0% 0% no-repeat padding-box",
background: "#2EB9AE 0% 0% no-repeat padding-box",
borderRadius: "8px",
opacity: 1,
borderColor: "white",
          }}
        >
      
         <h4 style={{
           textalign: "left",
           top: "648px",
marginLeft: "-227px",
width: "542px",
height: "22px",
         }}>Submit</h4>
        
         <i className="pi pi-chevron-right"></i>
        </Button>
        
        




        </form>


      </div>

    )
  }
}



const h3 = {
  top: "134px",
  left: "300px",
  width: "350px",
  height: "24px",
  font: "var(--unnamed-font-style-normal) normal var(--unnamed-font-weight-bold) var(--unnamed-font-size-20)/var(--unnamed-line-spacing-34) var(--unnamed-font-family-lato)",
  letterspacing: "var(--unnamed-character-spacing-0)",
  color: " var(--primary-blue)",
  textalign: "center",
  font: "normal normal bold 19px/34px Lato",
  letterspacing: "0px",
  color: "#2D5795",
  opacity: "1"
}
const p = {
  top: "164px",
  marginLeft: "79px",
  width: "208px",
  height: "39px",
  font: "italic normal var(--unnamed-font-weight-normal) var(--unnamed-font-size-16)/20px var(--unnamed-font-family-lato)",
  letterspacing: "var(--unnamed-character-spacing-0)",
  color: "var(--dark-gray)",
  textalign: "center",
  font: "italic normal normal 16px/20px Lato",
  letterSpacing: "0px",
  color: "#4A5058",
  opacity: 1
}
const label = {

  marginLeft: "-290px",
  width: "86px",
  height: "19px",
  font: "var(--unnamed-font-style-normal) normal var(--unnamed-font-weight-bold) var(--unnamed-font-size-16)/var(--unnamed-line-spacing-19) var(--unnamed-font-family-lato)",
  letterSpacing: "var(--unnamed-character-spacing-0)",
  color: "var(--dark-gray)",

  font: "normal normal bold 16px/19px Lato",
  letterSpacing: "0px",
  color: "#4A5058",

  opacity: 1,
}

const inputbox = {
  width: "340px", height: "50px", margin: "auto", marginBottom: "26px", background: "#F2F2F2"
}
const textarea={top: "356px",
left: "37px",
width: "340px",
height: "233px",
background:"#F2F2F2 0% 0% no-repeat padding-box",
borderRadius: "6px",
opacity: 1,
}
