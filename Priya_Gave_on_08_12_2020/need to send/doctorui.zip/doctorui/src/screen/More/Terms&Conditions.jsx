import React, { Component } from "react";
import "../../App.css";

export default class TermsConditions extends Component {
  render() {
    return (
      <div style={main}>
        <div>
          <form
            className="form"
            style={{ maxWidth: "26rem", marginLeft: "15px" }}
          >
            <a href="#" className="backArrowAboutUs"></a>

            <p
              style={{
                marginTop: "54px",
                marginLeft: "71px",
                width: "218px",
                height: "30px",
                font:
                  "var(--unnamed-font-style-normal) normal var(--unnamed-font-weight-bold) 25px/var(--unnamed-line-spacing-34) var(--unnamed-font-family-lato)",
                letterSpacing: "var(--unnamed-character-spacing-0)",
                color: "var(--dark-gray)",
                textAlign: "left",
                font: "normal normal bold 25px/34px Lato",
                letterSpacing: "0px",
                color: "#4A5058",
                opacity: 1,
              }}
            >
              Terms & Conditions
            </p>
            <br></br>
            <div></div>

            <p
              style={{
                textAlign: "center",
                marginTop: "15px",
                marginLeft: "37px",
                width: "341px",
                height: "57px",
                font:
                  "var(--unnamed-font-style-normal) normal var(--unnamed-font-weight-normal) var(--unnamed-font-size-16)/var(--unnamed-line-spacing-19) var(--unnamed-font-family-lato)",
                letterSpacing: "var(--unnamed-character-spacing-0)",
                color: " var(--dark-gray)",
                textAlign: "left",
                font: "normal normal normal 16px/19px Lato",
                letterSpacing: "0px",
                color: "#4A5058",
                opacity: 1,
              }}
            >
              These terms and conditions outline the rules and regulations for
              the use of Adwyse’s App, located at Playstore or AppStore
            </p>
            <p
              style={{
                textAlign: "center",
                marginTop: "36px",
                marginLeft: "36px",
                width: "56px",
                height: "19px",
                font:
                  "var(--unnamed-font-style-normal) normal var(--unnamed-font-weight-bold) var(--unnamed-font-size-16)/var(--unnamed-line-spacing-19) var(--unnamed-font-family-lato)",
                letterSpacing: "var(--unnamed-character-spacing-0)",
                color: "var(--primary-blue)",
                textAlign: "left",
                textAlign: "left",
                font: "normal normal bold 16px/19px Lato",
                letterSpacing: "0px",
                color: "#2D5795",
                opacity: "1",
              }}
            >
              General
            </p>
            <div>
              <p
                style={{
                  textAlign: "center",
                  marginTop: "20px",
                  marginLeft: "36px",
                  width: "341px",
                  height: "266px",
                  font:
                    "var(--unnamed-font-style-normal) normal var(--unnamed-font-weight-normal) var(--unnamed-font-size-16)/var(--unnamed-line-spacing-19) var(--unnamed-font-family-lato)",
                  letterSpacing: "var(--unnamed-character-spacing-0)",
                  color: "var(--dark-gray)",
                  textAlign: "left",
                  font: "normal normal normal 16px/19px Lato",
                  letterSpacing: "0px",
                  color: " #4A5058",
                  opacity: "1",
                }}
              >
                By accessing this website we assume you accept these terms and
                conditions. Do not continue to use adwyse.com if you do not
                agree to take all of the terms and conditions stated on this
                page. <br></br>
                <br></br>The following terminology applies to these Terms and
                Conditions, Privacy Statement and Disclaimer Notice and all
                Agreements: “Client”, “You” and “Your” refers to you, the person
                log on this website and compliant to the Company’s terms and
                conditions. “The Company”, “Ourselves”, “We”, “Our” and “Us”,
                refers to our Company. “Party”, “Parties”, or “Us”, refers to
                both the Client and ourselves.
              </p>
            </div>
            <div>
              <p
                style={{
                  textAlign: "center",
                  marginTop: "36px",
                  marginLeft: "36px",
                  width: "63px",
                  height: "19px",
                  font:
                    "var(--unnamed-font-style-normal) normal var(--unnamed-font-weight-bold) var(--unnamed-font-size-16)/var(--unnamed-line-spacing-19) var(--unnamed-font-family-lato)",
                  letterSpacing: "var(--unnamed-character-spacing-0)",
                  color: "var(--primary-blue)",
                  textAlign: "left",
                  font: "normal normal bold 16px/19px Lato",
                  letterSpacing: "0px",
                  color: "#2D5795",
                  opacity: "1",
                }}
              >
                Payment
              </p>
              <p
                style={{
                  textAlign: "center",
                  marginTop: "2px",
                  marginLeft: "37px",
                  width: "341px",
                  height: "247px",
                  font:
                    "var(--unnamed-font-style-normal) normal var(--unnamed-font-weight-normal) var(--unnamed-font-size-16)/var(--unnamed-line-spacing-19) var(--unnamed-font-family-lato)",
                  letterSpacing: "var(--unnamed-character-spacing-0)",
                  color: "var(--dark-gray)",
                  textAlign: "left",
                  font: "normal normal normal 16px/19px Lato",
                  letterSpacing: "0px",
                  color: "#4A5058",
                  opacity: "1",
                }}
              >
                All terms refer to the offer, acceptance and consideration of
                payment necessary to undertake the process of our assistance to
                the Client in the most appropriate manner for the express
                purpose of meeting the Client’s needs in respect of provision of
                the Company’s stated services, in accordance with and subject
                to, prevailing law of Netherlands.<br></br>
                <br></br> Any use of the above terminology or other words in the
                singular, plural, capitalization and/or he/she or they, are
                taken as interchangeable and therefore as referring to same.
              </p>
            </div>
          </form>
        </div>
      </div>
    );
  }
}
const main = {
  top: "0px",
  left: "0px",
  width: "50%",
  width: "414px",
  height: "896px",
  background: "#FFFFFF   0% 0% no-repeat padding-box",
  opacity: "1",
  margin: "auto",
};
