import React, { Component } from 'react';
import SVGImages from '../components/icons';
import { Link } from 'react-router-dom';
import { Button } from "primereact/button";

export default class BlogLandingPage extends Component {
  render() {
    return (
      <div style={{width:"414px",
                  height:"1020px",margin:"auto"}}
                >
          <div className="p-field"
                 style={{ width: "364px", margin: "auto", marginTop: "54px" }}
                  >
                <div className="p-d-flex p-ai-start">
                <div className="p-mr-2">
                <Link >
                <img src={SVGImages.BackArrow} alt="" 
                />
                </Link>
                </div>
<div style={myblogs}>My Blogs</div>
</div>
<div className="p-d-flex p-jc-center" style={{width:"364px",height:"150px",background:"#F2F2F2"}}>
<div className="p-d-flex p-ai-center">
    <div className="p-mr-2"><img src={SVGImages.Group60304} alt="" /></div>
    <div ><div style={name}> Dr. Abhishek Bachan</div>
    <div className="p-d-flex">
    <div className="p-mr-2" style={like}>43 Blogs</div>
    <div className="p-mr-2" style={like}>765 likes</div>
</div>
<div className="p-mr-2 p-mb-2" style={follow}>128 people follow you</div>
</div>
</div>
</div>
<div className="p-d-flex p-jc-between" style={{marginBottom:"30px",marginTop:"30px"}}>
    <div style={favouriteBlog}>Favourite Blogs</div>
    <div className="p-d-flex">
    <div className="p-mr-2" style={viewAll}>View All</div>
    <div className="p-mr-2"> <img src={SVGImages.RegularM} alt="" /></div>
</div>
</div>

<div className="p-d-flex p-jc-between">
    <div style={{width:"170px",height:"150px"}} className="groupimg">
       <div className="p-d-flex p-jc-between">
           <div></div>
           <div className="p-d-flex">
           <div className="p-mr-2" style={{color:"#ffffff"}} ><img src={SVGImages.Group60307} alt="" /></div>
           <div className="p-mr-2" style={{color:"#ffffff"}}>35</div>
           </div>
          
      </div>
   <div className="p-d-flex" style={{height: '150px'}}>
        <div className="p-d-flex p-jc-center" style={{width:"166px"}}>
        <div className="p-mr-2 p-as-center" style={{textAlign:"center",color:"#FFFFFF"}}>Pandemic : The perfect time for meditation</div>
   </div>
  </div>
  </div>   
  <div style={{width:"170px",height:"150px"}} className="groupimg1">
  <div className="p-d-flex p-jc-between">
      <div></div>
      <div className="p-d-flex">
           <div className="p-mr-2" style={{color:"#ffffff"}} ><img src={SVGImages.Group60307} alt="" /></div>
           <div className="p-mr-2" style={{color:"#ffffff"}}>35</div>
           </div>
   </div>
   <div className="p-d-flex" style={{height: '150px'}}>
   <div className="p-d-flex p-jc-center" style={{width:"166px"}}>
   <div className="p-mr-2 p-as-center" style={{textAlign:"center",color:"#FFFFFF"}}>Camp life in the time of COVID-19</div>
</div>
</div>
</div>
</div>

<div className="p-d-flex p-jc-between" style={{marginBottom:"15px",marginTop:"15px"}}>
    <div style={favouriteBlog}>Featured Blog</div>
</div>


<div style={{width:"364px",height:"150px"}} className="groupimg2">
<div className="p-d-flex p-jc-between">
    <div></div>
    <div className="p-d-flex">
    <div className="p-mr-2" style={{color:"#ffffff"}} ><img src={SVGImages.Group60307} alt="" /></div>
    <div className="p-mr-2" style={{color:"#ffffff"}}>35</div>
    </div>
 </div>
  <div className="p-d-flex" style={{height: '150px'}}>
  <div className="p-d-flex p-jc-center" style={{width:"364px"}}>
  <div className="p-mr-2 p-as-center" style={{textAlign:"center",color:"#FFFFFF"}}>Camp life in the time of COVID-19</div>
  </div>
</div>
</div>

<div className="p-d-flex p-jc-between" style={{marginBottom:"15px",marginTop:"15px"}}>
    <div>COVID 19</div>
    <div>Migraine</div>
    <div>Vaccinations</div>
    <div>Video Calling</div>
</div>

<div className="p-d-flex p-jc-between">
    <div style={{width:"150px",height:"150px"}} className="groupimg">
       <div className="p-d-flex p-jc-between">
           <div></div>
           <div style={{color:"#FFFFFF"}}>32</div>
      </div>
   <div className="p-d-flex" style={{height: '150px'}}>
        <div className="p-d-flex p-jc-center" style={{width:"166px"}}>
        <div className="p-mr-2 p-as-center" style={{textAlign:"center",color:"#FFFFFF"}}>Pandemic : The perfect time for meditation</div>
   </div>
  </div>
  </div>   
  <div style={{width:"196px",height:"150px"}}>
  
  <div className="p-d-flex p-flex-column">
    <div className="p-mb-2">“Collateral Beauty”: Emergency and emerging humanity in the COVID ICU</div>
    <div className="p-mb-2" style={{fontSize:"11px"}}>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores</div>
    </div>
   </div>
     
    </div>

    <div className="p-d-flex p-jc-center">
    <Button
    label="Add New Blog"
    style={{
       marginTop:"24px",
       width: "208px",
       font:'normal normal 600 20px/79px Lato',
       height: "57px",
       background: "#2EB9AE",
       borderRadius:"40px"
              }}
      ><div className="p-d-flex">
      <div className="p-mr-2"><img src={SVGImages.Group60310} alt="" /></div>
    </div></Button>
    </div>
      </div>
      </div>
    )

}
}


const headeingReschedule={
  width:"291px",
  height:"16px",
  color:"#4A5058",
  font:"normal normal bold 25px/34px Lato"
  }

  const myblogs={
    color:"#4A5058",
    font:"normal normal bold 25px/34px Lato",
    marginBottom:"30px"
  }
  const name={
    color:"#4A5058",
    font:"normal normal bold 21px/29px Lato", 
  }

const like ={
 font: 'normal normal 600 14px/19px Lato',
letterSpacing: '0px',
color: '#2D5795',
opacity:'1' 
  }

const follow={
font: 'italic normal 600 14px/19px Lato',
letterSpacing: '0px',
color: '#2EB9AE',
opacity: '1'
  }

  const favouriteBlog={
  font: 'normal normal bold 16px/26px Lato',
letterSpacing: '0px',
color: '#2D5795',
opacity: '1'
  }

  const viewAll={
letterSpacing: '0px',
color: '#4A5058',
opacity: '1',
font:'italic normal bold 14px/14px Lato'
  }