import React, { Component } from 'react'
import Button from '@material-ui/core/Button';
import SVGImages from '../components/icons';


export default class Appointments extends Component {
  demo(){
    alert("hiii------>");
  }
  render() {
    return (
      <div style={{width:"414px",height:"896px"}}>
      <div className="p-field" style={{width:"364px",margin:"auto",marginTop:"60px"}}>
      <div className="p-d-flex p-flex-column">
      <div className="p-mb-2" style={appontmentHHeading}>Appointments</div>
      <div className="p-mb-2">You can view all your scheduled, upcoming, completed & cancelled appointments here.</div>
      <Button  
              style={{
                background:'red',
                height:"119px",
                width:"364px"
              }} 
              
      > 
    <div className="p-d-flex">
    <div className="p-mr-2"> <img  src={SVGImages.AccountIcon} alt="" /></div>
    <div className="p-mr-2" onClick={this.demo()}>Confirmed Appointments</div>
    </div>
    <div className="p-d-flex" style={{width:"300px"}}>
    <div className="p-mr-2">Confirmed Appointments</div>
    
    </div>
      </Button>
      </div>  
      </div>
      </div>
    )
  }
}


const appontmentHHeading={
  textAlign: 'left',
font: 'normal normal bold 30px/34px Lato',
letterSpacing: '0px',
color: '#4A5058',
opacity: '1'
}