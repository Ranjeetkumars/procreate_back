import React from 'react';
import {connect} from 'react-redux';
import { InputText } from 'primereact/inputtext';
import Button from '@material-ui/core/Button';
import AdwyseHeading from '../components/AdwyseHeading';
import Carousel from '../components/Carousel';
import SVGImages from '../components/icons';
import axios from '../axios/axios';



 class AccountInformation extends React.Component {
  constructor(props) {
    super(props);
    this.state = { 
      accountholderName: '',
      accountNumber: '',
      bankName: '',
      ifscCode:'',
      error:'',
      backroute:"/Awards_Recognition"
      
    };
  }

  submitHandler = (e) => {
    const { accountholderName, accountNumber, bankName ,ifscCode} = this.state;
    e.preventDefault();
    if (!this.state.accountholderName || !this.state.accountNumber || !this.state.bankName
      ||!this.state.ifscCode) {
        this.setState(() => ({ error: 'Please Enter all the field!' }));
    } else {
        this.setState(() => ({ error: '' }));
        this.props.dispatch({
          type: 'ADD_ACCOUNT_INFORMATION',
          payload: { accountholderName, accountNumber, bankName, ifscCode }
        });

       const {state } = this.props;
       const accountInfo=state.accountInfo
       const prsnDetails=state.prsnDetails
       const professional=state.professional;
       const awards=state.awards;
       
       
       console.log(JSON.stringify(prsnDetails));
       const obj={
        "id": 2,
        "first_name": prsnDetails.firstname,
        "last_name": prsnDetails.lastname,
        "email": prsnDetails.emailaddress,
        "password": "kvnsvnisvsvsmvi",
        "phone_number": prsnDetails.phonenumber,
        "clinic_number": prsnDetails.clinicnumber,
        "gender": prsnDetails.gender,
        "dob": prsnDetails.dateofbirth,
        "term_Conditions": true,
        "organization": {
          "id": 1,
          "type": "company",
          "name": "Procreate"
        },
        "roles": [{
          "id": 1,
          "name": "Admin"
        }, {
          "id": 2,
          "name": "Doctor"
        }],
        "address": {
          "line1": prsnDetails.addressline1,
          "line2": prsnDetails.addressline2,
          "city": prsnDetails.townCity,
          "state": {
            "id": 10,
            "name": prsnDetails.stateRegion
          }
        },
        "profile": {
          "professional_details": {
            "profile_img": "home/images/img1.jpg",
            "medical_registration_number": professional.medicalRegistrationNo,
            "qualifications": [{
              "id": 10,
              "name": professional.qualification
            }],
            "specialization": [{
              "id": 10,
              "name": "Urologist"
            }, {
              "id": 12,
              "name": "Dentist"
            }],
            "experince_in_years": 5,
            "awards_Recognitions": {
              "awards": [{
                "name": awards.Awards,
                "attachment": "home/images/img2.jpg"
              }],
              "recognitions": [{
                "name": awards.Recognitions,
                "attachment": "home/images/img3.jpg"
              }]
            },
            "account_Information": {
              "account_holder_name": accountInfo.accountholderName,
              "account_number": accountInfo.accountNumber,
              "bank": {
                "id": accountInfo.ifscCode,
                "name": accountInfo.bankName
              }
            },
            "consultation_Fees": {
              "video_Call": {
                "duration_in_minutes": "10",
                "fees": [{
                  "amount": 500,
                  "unit": {
                    "id": 1,
                    "symbol": "INR",
                    "symbol_img": "inr_symbol_image_path.jpg"
                  }
                }, {
                  "amount": 10,
                  "unit": {
                    "id": 2,
                    "symbol": "USD",
                    "symbol_img": "usd_symbol_image_path.jpg"
                  }
                }]
              },
              "text_Call": {
                "duration_in_minutes": "10",
                "fees": [{
                  "amount": 500,
                  "unit": {
                    "id": 1,
                    "symbol": "INR",
                    "symbol_img": "inr_symbol_image_path.jpg"
                  }
                }, {
                  "amount": 10,
                  "unit": {
                    "id": 2,
                    "symbol": "USD",
                    "symbol_img": "usd_symbol_image_path.jpg"
                  }
                }]
              },
              "audio_Video_Call": {
                "duration_in_minutes": "10",
                "fees": [{
                  "amount": 500,
                  "unit": {
                    "id": 1,
                    "symbol": "INR",
                    "symbol_img": "inr_symbol_image_path.jpg"
                  }
                }, {
                  "amount": 10,
                  "unit": {
                    "id": 2,
                    "symbol": "USD",
                    "symbol_img": "usd_symbol_image_path.jpg"
                  }
                }]
              },
              "followup_Call": {
                "duration_in_minutes": "10",
                "fees": [{
                  "amount": 500,
                  "unit": {
                    "id": 1,
                    "symbol": "INR",
                    "symbol_img": "inr_symbol_image_path.jpg"
                  }
                }, {
                  "amount": 10,
                  "unit": {
                    "id": 2,
                    "symbol": "USD",
                    "symbol_img": "usd_symbol_image_path.jpg"
                  }
                }]
              },
              "availability_Schedule": {
                "include_holidays": false,
                "daywise_Schedule": [{
                    "name": "Monday",
                    "slots": [{
                      "start_time": "0900",
                      "end_time": "1200"
                    }, {
                      "start_time": "1400",
                      "end_time": "1800"
                    }]
                  }, {
                    "name": "Tuesday",
                    "slots": [{
                      "start_time": "0900",
                      "end_time": "1200"
                    }, {
                      "start_time": "1400",
                      "end_time": "1800"
                    }]
                  },
                  {
                    "name": "Wednesday",
                    "slots": [{
                      "start_time": "0900",
                      "end_time": "1200"
                    }]
                  }

                ]
              }
            }

          }
        }
      }
       
      
      axios.post('/userReg/user_Registration',{obj}).then((res) => {
           console.log(res);
           this.props.history.push("/ProfilePreview");
         })
  }
  }

  componentDidMount() {
    const {state } = this.props;
    const accountInfo=state.accountInfo;
    if(!accountInfo==''){
     this.setState({accountholderName:accountInfo.accountholderName,accountNumber:accountInfo.accountNumber,bankName:accountInfo.bankName,ifscCode:accountInfo.ifscCode})
   }
  }

  render(){
  return (
    <div style={main}>
    <form  onSubmit={this.submitHandler}>
    <div>
    <div style={{marginLeft:"17px"}}>
    <AdwyseHeading fromParaent={this.state.backroute} />
    </div>
     <div className="p-field" style={{width:"340px",margin:"auto"}}> 
          <div>
          <h3 style={letGetStarted}>Let's get started!</h3>
          </div>
         <div>
         <img  src={SVGImages.AccountIcon} alt="" />
         </div>
         <label htmlFor="username1" 
                className="p-d-block" 
                style={label}>Account holder Name
          </label>
         <InputText id="accountholderName" 
                    value={this.state.accountholderName}  
                    onChange={(e) => this.setState({accountholderName: e.target.value})} 
                    aria-describedby="username1-help" 
                    className="p-d-block" 
                    placeholder="Please enter account holder name" 
                    style={inputbox}/>
         <label htmlFor="username1" 
               className="p-d-block">
               Account Number*
          </label>
         <InputText id="accountNumber" 
                   value={this.state.accountNumber} 
                   onChange={(e) => this.setState({accountNumber: e.target.value})} 
                   aria-describedby="username1-help" 
                   className="p-d-block" 
                   placeholder="Please enter account number" 
                   style={inputbox}/>
         <label htmlFor="username1" 
                   className="p-d-block">
                   Bank Name</label>
         <InputText id="bankName" 
                    value={this.state.bankName}  
                    onChange={(e) => this.setState({bankName: e.target.value})}
                    aria-describedby="username1-help" 
                    className="p-d-block" 
                    placeholder="Please enter bank name" 
                    style={inputbox}/>
         <label htmlFor="bankName" 
                className="p-d-block">IFSC Code</label>
         <InputText id="ifscCode" 
                    value={this.state.ifscCode}  
                    onChange={(e) => this.setState({ifscCode: e.target.value})}
                    aria-describedby="username1-help" 
                    className="p-d-block" 
                    placeholder="Please enter IFSC Code" 
                    style={inputbox}/>
         <Button variant="contained" 
                type="submit" 
                color="primary" 
                style={button}>
         Confirm & Continue
         </Button>
         <p style={{width:"87px",color:"#4A5058",font:"normal normal bold 18px/22px Lato",margin:"auto"}}>Do it Later</p>
         <div style={{marginTop:"-20px",marginLeft:"11px"}}>
         <Carousel/>
          </div>
         </div>
         
        </div>
        </form>
    </div>
  );
}
}

const mapStateToProps = state => {
  return { state: state }
}

export default connect(mapStateToProps) (AccountInformation) 


const main={
    top: "0px",
    left: "0px",
    width: "50%",
    width: "414px",
    height: "896px",
    background: "#FFFFFF   0% 0% no-repeat padding-box",
    opacity: "1",
    margin:"auto"
    }

    const letGetStarted={
      fontSize:"20px",color:"#2D5795"
    }

    const label={
      marginLeft:"23px",marginTop:"-20px"
    }

    const inputbox={
      width:"340px",height:"50px",margin:"auto",marginBottom:"26px",background:"#F2F2F2"
    }

    const button={
      backgroundColor:"#2EB9AE",width:"340px",height:"50px",margin:"auto",marginBottom:"26px"
    }