import React, { Component } from 'react'
import DoctorAvailability from '../components/DoctorAvailability';

export default class Availability extends Component {
  render() {
    return (
      <div>
        <DoctorAvailability/>
      </div>
    )
  }
}
