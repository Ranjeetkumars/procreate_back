import React from 'react';
//import './App.css';
import {Button}from "primereact/button";


function RescheduleAppointment() {
  return (
    <React.Fragment>
      
<div align="center"height="896px"width="414">

<div   style={{width:"414px",height:"896px",align:"center"}}name="form"align="center">
  <h1 style={headeingReschedule}>Re-ScheduleAppointment</h1>
  <p>APPOINTMENT SUMMARY</p>

  <div className="p-d-flex"style={{width:"95px",height:"105px",align:"center"}}>
    <div className="p-mr-2"><img src="C:\Users\rajesh raj\Desktop\a.png"height="40px"width="70px"></img></div>
    <div className="p-mr-2"style={{width:"36",height:"12px",color:"#4A5058",top:"162px",left:"140px"}}>Name  AliaBhat</div>

    <div className="p-mr-2"style={{width:"36",height:"12px",color:"#4A5058",top:"162px",left:"140px"}}>FEES  500rs</div>
</div> 
  
  <Button style={{backgroundColor:"#2D5795"}}>ResheduleAppointment</Button>
  <br></br>
 <p>Note:you can re schedule your appiontment depending on</p>
 <p>your convenience,patient will be informed the same</p>


 <div className="p-d-flex"style={{width:"95px",height:"105px",align:"center"}}>
 <div className="p-mr-2"><img src="C:\Users\rajesh raj\Desktop\d.svg"height="30px"width="30px"></img></div>
 <div className="p-mr-2"style={{width:"36",height:"12px",color:"#4A5058",top:"162px",left:"140px"}}>Date</div>
 <div className="p-mr-2"><img src="C:\Users\rajesh raj\Desktop/t.svg"height="30px"width="30px"></img></div>
 <div className="p-mr-2"style={{width:"36",height:"12px",color:"#4A5058",top:"162px",left:"140px"}}>time  </div>
</div>

<div className="p-d-flex">
    <div className="p-mr-2 p-order-3"><input type="text"placeholder="Enter time"style={{height:"50px",width:"160px",backgroundColor:"#F2F2F2"}}></input></div>
    <div className="p-mr-2 p-order-1"><input type="text"placeholder="DD/MM/YYYY"style={{height:"50px",width:"160px",backgroundColor:"#F2F2F2"}}></input></div>
    
</div>


 <div>
 
 <p style={{fontColor:"#B3BCC7"}}>Note :You can only re Schedule the appointment on the same day or for the next day.</p>
 </div>

 <Button label="Confirm & Re Schedule Appointment"className="p-button-sucess"/><br></br>

 <Button label="Cancel the appointment" className="p-button-danger p-button-text" />
 
 
</div>

</div>



    </React.Fragment>



    
  );

}

export default RescheduleAppointment;



const headeingReschedule={

width:"291px",
height:"16px",
color:"#4A5058",
font:"normal normal bold 25px/34px Lato"
}