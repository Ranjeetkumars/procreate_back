import React, { Component } from 'react'
import {Button}from "primereact/button";
import { Calendar } from 'primereact/calendar';
import SVGImages from '../components/icons';
import { Link } from 'react-router-dom';


export default class RescheduleAppointment2 extends Component {
  constructor(props) {
    super(props);

    let today = new Date();
    let month = today.getMonth();
    let year = today.getFullYear();
    let prevMonth = (month === 0) ? 11 : month - 1;
    let prevYear = (prevMonth === 11) ? year - 1 : year;
    let nextMonth = (month === 11) ? 0 : month + 1;
    let nextYear = (nextMonth === 0) ? year + 1 : year;

    this.state = {
        date1: null,
    }
  }

  render() {
    return (
      <div style={{width:"414px",height:"896px",margin: "auto"}}>
      <div style={{width:"364px",margin: "auto",marginTop:"54px"}}>
       <div className="p-d-flex" style={{marginBottom:"20px"}}>
        <div className="p-mr-2 p-mb-2"> <Link>
        <img src={SVGImages.BackArrow} alt="" />
        </Link>
        </div>
        <div className="p-mr-2 p-mb-2" style={reschedule}>Re-Schedule Appointment</div>
       </div>

       <div className="p-d-flex">
          <div className="p-mr-2 p-mb-2" style={appointsummary}>APPOINTMENT SUMMARY</div>
        </div>

        <div className="p-d-flex">
          <div className="p-mr-2 p-mb-2" style={calenderTime}>8:30 pm</div>
          <div className="p-mr-2 p-mb-2" style={calenderTime}>23rd November 2020</div>
          <div className="p-mr-2 p-mb-2" style={calenderTime}>Tuesday</div>
        </div>

        <div className="p-d-flex p-jc-center" style={{background:"#F2F2F2",marginBottom:"20px",marginTop:"15px",height:"30px"}}>
          <div className="p-mr-2 p-as-center" style={message}>Message</div>
          <div className="p-mr-2 p-as-center" style={message}>Follow up appointment</div>
        </div>

<div className="p-d-flex p-jc-between" style={{heigth:"105px"}}>
  <div>
        <div className="p-d-flex">
         <div className="p-mr-2" ><img style={{height:"95px"}} src={SVGImages.Group60350} alt="" /></div>
        <div className="p-mr-2">
        <div className="p-d-flex p-flex-column">
            <div style={appointsummary}>A NAME</div>
            <div className="p-mt-auto" style={calenderTime}>Alia Bhatt</div>
        <div className="p-d-flex p-flex-column" style={{height: '53px'}}>

       <div className="p-mt-auto" >
          <div className="p-mt-auto" >MEDICAL ISSUE</div>
           <div className="p-mt-auto" style={healthcare}>Headache, Cold & Fever</div>
       </div>
    </div>
    </div>
    </div>
  </div>
</div>
        <div>
        <div className="p-d-flex p-flex-column">
          <div >Fees</div>
         <div className="p-mt-auto" >₹500</div>
           </div>
        </div>
        </div><br></br>
         <Button style={reschedulebtn} label="Re-Schedule Appointment"className="p-button-sucess"/>
         <div style={schdulesdesc}>
         You can re schedule your appointment depending on your convenience, patient will be informed the same.
         </div><br></br>

         <div className="p-d-flex p-jc-between">
         <div style={{width:"160px"}}>
                            <label htmlFor="basic" style={label}>Date</label>
                            <Calendar id="basic" value={this.state.date1} placeholder="DD / MM / YYYY" onChange={(e) => this.setState({ date1: e.value })} style={{color:"#BFBFBF"}} />
              </div>
         <div style={{width:"160px"}}>
        
         <div className="p-d-flex">
          <div className="p-mr-2">  <img src={SVGImages.Group60258} alt="" /></div>
          <label htmlFor="basic" style={label}>Time</label>
         </div>
           
           <Calendar id="time12" value={this.state.date9} placeholder="Enter the time" onChange={(e) => this.setState({ date9: e.value })} timeOnly hourFormat="12" />

           
           </div>
        </div><br></br>
        <Button style={confirmbtn} label="Confirm & Re Schedule Appointment"className="p-button-sucess"/>

        <Button label="Cancel the appointment" style={{width:"364px"}} className="p-button-danger p-button-text" />
         </div>
      </div>
    )
  }
}


const appointsummary={
  width: '183px',
height: '15px',
  font: 'normal normal bold 12px/21px Lato',
letterSpacing: '1.2px',
color: '#8B8B8B',
textTransform: 'uppercase',
opacity: '1'
}

const reschedule={
  width: '291px',
height: '30px',
textAlign: 'left',
font: 'normal normal bold 25px/34px Lato',
letterSpacing: '0px',
color: '#4A5058',
opacity: '1'
}

const calenderTime={
  font: 'normal normal bold 16px/26px Lato',
letterSpacing: '0px',
color: '#4A5058'
}

const label={
  font: 'normal normal bold 16px/26px Lato',
  letterSpacing: '0px',
  color: '#4A5058'
}

const healthcare={
  font: 'normal normal bold 16px/19px Lato',
letterSpacing: '0px',
color: '#CC5141',
opacity:'1'
}

const reschedulebtn={
  width:"190px",
  fontSize:"13px",
  background: '#2D5795 0% 0% no-repeat padding-box',
borderRadius: '3px',
opacity: '1'
}

const schdulesdesc={
font: 'italic normal medium 14px/20px Lato',
letterSpacing: '0px',
color: '#4A5058',
width:"337px",
heigth:"37px",
fontSize:"14px",
opacity: '1'
}

const confirmbtn={
  width:"364px",
  background: '#52B46C 0% 0% no-repeat padding-box',
  marginBottom:"20px"

}

const message={
  font: 'normal normal bold 15px/14px Lato',
letterSpacing: '0px',
color: '#4A5058',
opacity: '1'
}