import React, { Component } from "react";
import AdwyseHeading from "../components/AdwyseHeading";
import ResetPassword from "../components/ResetPassword";
import { InputText } from "primereact/inputtext";
import { Button } from "primereact/button";
import axios from "axios";
import { connect } from "react-redux";

class LoginOtpVerification extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      color: successcolor,
      incorrectOtp: {
        title: "INCORRECT OTP",
        message: "The OTP you have entered is incorrect. Please try again..",
      },
      otpResent: {
        title: "OTP RESENT",
        message: "OTP has been resent to your phone number!",
      },
      otp1: "",
      otp2: "",
      otp3: "",
      otp4: "",
    };
  }

  loginWithOtp = (evt) => {
    evt.preventDefault();
    const { otp1, otp2, otp3, otp4 } = this.state;
    const { phoneNumber } = this.props;
    const phonenum = phoneNumber;
    const otp = otp1 + otp2 + otp3 + otp4;

    axios
      .post(
        "http://localhost:1500/onlinePortalControler/verifOTPForActivation",
        {
          phonenum,
          otp,
        }
      )
      .then((result) => {
        let strResult = JSON.stringify(result.data.strResultType);
        if ((strResult = 1)) {
          alert("Login Sucessfully");
          this.props.history.push("/ProfilePreview");
        } else {
          alert("Not Login ");
        }
      });
  };
  updateOtp1 = (evt) => {
    this.setState({ otp1: evt.target.value });
  };
  updateOtp2 = (evt) => {
    this.setState({ otp2: evt.target.value });
  };
  updateOtp3 = (evt) => {
    this.setState({ otp3: evt.target.value });
  };
  updateOtp4 = (evt) => {
    this.setState({ otp4: evt.target.value });
  };
  render() {
    return (
      <form onSubmit={this.loginWithOtp}>
        <div style={main}>
          <div>
            <ResetPassword fromParent={this.state} />
            <div style={{ marginLeft: "38px" }}>
              <div style={{ marginTop: "37px", fontSize: "22px" }}>
                <h3
                  style={{
                    fontSize: "20px",
                    color: "#2D5795",
                    margin: "initial",
                  }}
                >
                  OTP Verification
                </h3>
              </div>
              <div className="p-d-flex p-jc-start">
                <div className="p-mr-2">
                  <span>Enter the OTP sent to?</span>
                </div>
                <div>Nameer@getnoor.com</div>
              </div>
              <div style={{ width: "340px", marginTop: "8px" }}>
                <div className="p-fluid p-formgrid p-grid">
                  <div className="p-field p-col">
                    <InputText
                      style={inputbox}
                      id="otp1"
                      type="text"
                      value={this.state.otp1}
                      onChange={this.updateOtp1}
                    />
                  </div>
                  <div className="p-field p-col">
                    <InputText
                      style={inputbox}
                      id="otp2"
                      type="text"
                      value={this.state.otp2}
                      onChange={this.updateOtp2}
                    />
                  </div>
                  <div className="p-field p-col">
                    <InputText
                      style={inputbox}
                      id="otp3"
                      type="text"
                      value={this.state.otp3}
                      onChange={this.updateOtp3}
                    />
                  </div>
                  <div className="p-field p-col">
                    <InputText
                      style={inputbox}
                      id="otp4"
                      type="text"
                      value={this.state.otp4}
                      onChange={this.updateOtp4}
                    />
                  </div>
                </div>
                <div className="p-d-flex p-jc-start">
                  <div className="p-mr-2">
                    <span>Enter the OTP sent to?</span>
                  </div>
                  <div
                    style={{
                      color: "#2D5795",
                      font: "normal normal bold 16px/19px Lato",
                      marginBottom: "24px",
                    }}
                  >
                    Resend OTP
                  </div>
                </div>
                <Button
                  label="Verify OTP"
                  style={{
                    width: "340px",
                    height: "50px",
                    background: "#2EB9AE",
                  }}
                />
              </div>
            </div>
          </div>
        </div>
      </form>
    );
  }
}
const mapStateToProps = (store) => {
  return { phoneNumber: store.phonenum };
};
export default connect(mapStateToProps)(LoginOtpVerification);

const successcolor = "#52B46C";
const errorcolor = "#CC2929";

const main = {
  top: "0px",
  left: "0px",
  width: "50%",
  width: "414px",
  height: "896px",
  background: "#FFFFFF   0% 0% no-repeat padding-box",
  opacity: "1",
  margin: "auto",
};

const inputbox = {
  width: "72px",
  height: "72px",
  background: "#F2F2F2",
  textAlign: "center",
};
