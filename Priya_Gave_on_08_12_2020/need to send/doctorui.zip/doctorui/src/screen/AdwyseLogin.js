import React, { Component } from "react";
import axios from "axios";

import "primeicons/primeicons.css";
import "primereact/resources/themes/saga-blue/theme.css";
import "primereact/resources/primereact.css";
import "primeflex/primeflex.css";
import { InputText } from "primereact/inputtext";
import { Button } from "primereact/button";
import AdwyseHeading from "../components/AdwyseHeading";
import SVGImages from "../components/icons";
import { Link } from 'react-router-dom';
import ResetPassword from "../components/ResetPassword";
import { connect } from "react-redux";
import store from "../store/store";

class AdwyseLogin extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      phonenum: "",
      color: successcolor,
      resetSuccessful: {
        title: "Reset successful",
        message:
          "Your password has been successfully Reset, you can now try logging in again",
      },
      incorrectEmail: {
        title: "INCORRECT email",
        message: "The email you have entered is incorrect. Please try again..",
      },
    };
  }
  //2)Read From   PhoneNum To Redux Store
  loginWithoutOtp = (evt) => {
    evt.preventDefault();
    const { phonenum } = this.state;
    //1)Set From PhoneNum To Redux Store
    const { dispatch } = this.props;
    dispatch({ type: "UPDATE_PHONENUM", payload: phonenum });
    axios
      .post(
        "http://localhost:1500/onlinePortalControler/resendOTPForRegistration",
        {
          phonenum,
        }
      )
      .then((result) => {
        let responseCode = JSON.stringify(result.data.responseCode);
        if ((responseCode = 200)) {
          this.props.history.push("/LoginOtpVerification");
        } else {
          alert("Not Login ");
        }
      });
  };

  updateInput = (evt) => {
    const { phonenum } = this.state;
    //1)Set From PhoneNum To Redux Store
    const { dispatch } = this.props;
    dispatch({ type: "UPDATE_PHONENUM", payload: phonenum });
    this.setState({ phonenum: evt.target.value });
  };

  loginWithouPassWordScreen = (evt) => {
    evt.preventDefault();
    const { phonenum } = this.state;
    //1)Set From PhoneNum To Redux Store
    const { dispatch } = this.props;
    dispatch({ type: "UPDATE_PHONENUM", payload: phonenum });
    this.props.history.push("/LoginWithPassword");
  };
  render() {
    const { phoneNumber } = this.props;
    const { phonenum } = this.state;
    //  alert("From State phonenum" + phonenum);

    // alert("From Store phoneNumber" + phoneNumber);

    return (
      <form onSubmit={this.loginWithoutOtp}>
        <div style={main}>
          <div>
            <div>
              <AdwyseHeading />
            </div>
            <div className="p-field" style={{ width: "340px", margin: "auto" }}>
              <div>
                <h3 style={{ fontSize: "20px", color: "#2D5795" }}>
                  Let's get started!
                </h3>
              </div>
              <div>
                <img src={SVGImages.AccountIcon} alt="" />
              </div>
              <label htmlFor="username1" className="p-d-block" style={label}>
                Email/Phone Number
              </label>
              <InputText
                aria-describedby="username1-help"
                className="p-d-block"
                placeholder="Please enter your mail or phone number"
                style={inputbox}
                value={this.state.phonenum}
                onChange={this.updateInput}
              />
              <Button label="Login with OTP" style={loginwithotp} />
              <Button
                label="Login with Password"
                style={forgotpassword}
                onClick={this.loginWithouPassWordScreen}
              />
              <div className="p-d-flex p-jc-center">
                <div className="p-mr-2">
                  <span>Don't Have Account ?</span>
                </div>
                <Link to="/">
                Register Now
                </Link>  
              </div>
            </div>
            <div>
              <img style={Image} src={SVGImages.Image} alt="" />
            </div>
          </div>
        </div>
      </form>
    );
  }
}
const mapStateToProps = (store) => {
  return { phoneNumber: store.phonenum };
};

const mapDispatchToProps = (dispatch) => {
  return { dispatch };
};
export default connect(mapStateToProps, mapDispatchToProps)(AdwyseLogin);

const successcolor = "#52B46C";
const errorcolor = "#CC2929";

const main = {
  top: "0px",
  left: "0px",
  width: "50%",
  width: "414px",
  height: "896px",
  background: "#FFFFFF   0% 0% no-repeat padding-box",
  opacity: "1",
  margin: "auto",
};

const inputbox = {
  width: "340px",
  height: "50px",
  margin: "auto",
  marginBottom: "26px",
  background: "#F2F2F2",
};

const loginwithotp = {
  width: "340px",
  height: "50px",
  background: "#2EB9AE",
  marginBottom: "26px",
};

const forgotpassword = {
  width: "340px",
  height: "50px",
  background: "#2D5795 ",
  marginBottom: "26px",
};

const label = {
  marginLeft: "26px",
  marginTop: "-20px",
};

const Image = {
  marginTop: "78px",
  width: "414px",
  height: "319px",
  marginLeft: "1px",
};
