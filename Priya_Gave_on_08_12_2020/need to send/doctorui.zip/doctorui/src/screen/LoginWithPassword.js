import React, { Component } from "react";
import { InputText } from "primereact/inputtext";
import { Button } from "primereact/button";
import AdwyseHeading from "../components/AdwyseHeading";
import SVGImages from "../components/icons";
import ResetPassword from "../components/ResetPassword";
import axios from "axios";
import { connect } from "react-redux";

class LoginWithPassword extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      password: "",
      color: successcolor,
      resetSuccessful: {
        title: "Reset successful",
        message:
          "Your password has been successfully Reset, you can now try logging in again",
      },
      incorrectEmail: {
        title: "INCORRECT email",
        message: "The email you have entered is incorrect. Please try again..",
      },
    };
  }
  loginWithPassWord = (evt) => {
    evt.preventDefault();
    const { password } = this.state;
    const { phoneNumber } = this.props;
    const emailid = phoneNumber;
    axios
      .post(
        "http://localhost:1500/onlinePortalControler/loginWithEmailAndPassword",
        {
          emailid,
          password,
        }
      )
      .then((result) => {
        let responseCode = JSON.stringify(result.data.responseCode);
        if ((responseCode = 200)) {
          this.props.history.push("/ProfilePreview");
        } else {
          alert("Not Login ");
        }
      });
  };

  updateInput = (evt) => {
    this.setState({ password: evt.target.value });
  };
  render() {
    // alert(""+this.state.color)
    //<ResetPassword fromParent ={this.state}/>
    return (
      <form onSubmit={this.loginWithPassWord}>
        <div style={main}>
          <div>
            <div>
              <AdwyseHeading />
            </div>
            <div
              className="p-field"
              style={{ width: "340px", margin: "auto", marginTop: "23px" }}
            >
              <div
                className="p-d-flex p-jc-start"
                style={{ marginBottom: "12px" }}
              >
                <div
                  className="p-mr-2"
                  style={{
                    fontSize: "20px",
                    color: "#2D5795",
                    margin: "initial",
                  }}
                >
                  Enter Password
                </div>
              </div>
              <div
                className="p-d-flex p-jc-start"
                style={{ marginBottom: "12px" }}
              >
                <div className="p-mr-2" style={{ fontSize: "15px" }}>
                  Enter the password associated with your account
                </div>
              </div>
              <label htmlFor="username1" className="p-d-block" style={label}>
                Enter Password
              </label>
              <InputText
                id="username1"
                aria-describedby="username1-help"
                className="p-d-block"
                placeholder="Please enter password"
                style={inputbox}
                value={this.state.password}
                onChange={this.updateInput}
              />
              <div className="p-d-flex p-jc-start">
                <div className="p-mr-2">Forgot Password</div>
                <div>
                  <Button
                    label="Reset Now"
                    className="p-button-link"
                    style={{
                      marginTop: "-7px",
                      marginLeft: "-16px",
                      color: "#2D5795",
                      font: "normal normal bold 16px/19px Lato",
                    }}
                  />
                </div>
              </div>
              <Button label="Login" style={loginwithotp} />
            </div>
          </div>
        </div>
      </form>
    );
  }
}
const mapStateToProps = (store) => {
  return { phoneNumber: store.phonenum };
};

export default connect(mapStateToProps)(LoginWithPassword);

const successcolor = "#52B46C";
const errorcolor = "#CC2929";

const main = {
  top: "0px",
  left: "0px",
  width: "50%",
  width: "414px",
  height: "896px",
  background: "#FFFFFF   0% 0% no-repeat padding-box",
  opacity: "1",
  margin: "auto",
};

const inputbox = {
  width: "340px",
  height: "50px",
  margin: "auto",
  marginBottom: "20px",
  background: "#F2F2F2",
};

const loginwithotp = {
  width: "340px",
  height: "50px",
  background: "#2EB9AE",
  marginBottom: "26px",
};

const forgotpassword = {
  width: "340px",
  height: "50px",
  background: "#2D5795 ",
  marginBottom: "26px",
};

const label = {};

const Image = {
  marginTop: "78px",
  width: "414px",
  height: "319px",
  marginLeft: "1px",
};
