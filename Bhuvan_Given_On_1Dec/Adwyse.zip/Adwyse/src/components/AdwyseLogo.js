import React from 'react'
import '../App.css';
import '../assets/css/PersonalDetailsStepTwoLogo.css';

const AdwyseLogo = () => {
   return (
      <div>
         <div>
            <button className="backArrow" type="submit" />
         </div>
         <div className="headingLogo">
         </div>
      </div>
   )   
}

export default AdwyseLogo;