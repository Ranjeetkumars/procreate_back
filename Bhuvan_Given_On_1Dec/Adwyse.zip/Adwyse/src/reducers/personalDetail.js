const personalDetailsReducerDefaultState = [];

const initialState = {
  allBMIs: [],
}


// export default (state = allBMIs, action) => {
//     switch (action.type) {
//         case 'ADD_PERSONAL_DETAILS':
//             return [
//                 ...state,
//                 action.book
//             ];
//         case 'ADD_PROFESSIONAL_DETAILS':
//             return [
//                 ...state,
//                 action.book
//             ];
       
//     }
   
// return state;
// };





