#!/bin/sh

docker build -t hapi-fhir/hapi-fhir-jpaserver-starter .

