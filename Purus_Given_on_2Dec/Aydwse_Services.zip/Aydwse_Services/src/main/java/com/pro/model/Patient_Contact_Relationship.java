package com.pro.model;

import java.util.List;

import lombok.Data;

@Data
public class Patient_Contact_Relationship {
	
	private List<Patient_Contact_Relationship_Coding> coding;

}
