package com.pro.model;

import lombok.Data;

@Data
public class Kyc 
{
private String document_img;
private Doc_Type  type;

}
