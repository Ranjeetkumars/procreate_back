package com.pro.model;

import lombok.Data;

@Data
public class ReciverType
{
private String id;
private String name;


}
