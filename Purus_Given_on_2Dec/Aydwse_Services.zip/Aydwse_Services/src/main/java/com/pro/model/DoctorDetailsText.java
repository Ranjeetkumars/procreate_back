package com.pro.model;

import lombok.Data;

@Data
public class DoctorDetailsText {

	private String status;
	private String div;
}
