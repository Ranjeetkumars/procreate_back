package com.pro.model;

import lombok.Data;

@Data
public class Sender_Type 
{
	private int id;
	
	private String name;

}
