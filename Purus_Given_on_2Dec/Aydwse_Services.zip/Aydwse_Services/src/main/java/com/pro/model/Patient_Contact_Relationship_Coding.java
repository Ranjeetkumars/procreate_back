package com.pro.model;


import lombok.Data;

@Data
public class Patient_Contact_Relationship_Coding {
	
	private String system;
	
	private String code;
	
	

}
