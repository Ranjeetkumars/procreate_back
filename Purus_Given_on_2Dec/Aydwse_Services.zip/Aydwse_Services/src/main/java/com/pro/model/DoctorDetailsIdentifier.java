package com.pro.model;

import lombok.Data;

@Data
public class DoctorDetailsIdentifier {

	private String use;
	private String system;
	private String value;
	
	
	
}
