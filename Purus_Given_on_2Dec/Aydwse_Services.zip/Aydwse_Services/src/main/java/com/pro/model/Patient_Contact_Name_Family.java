package com.pro.model;

import java.util.List;

import lombok.Data;

@Data

public class Patient_Contact_Name_Family
{
	
	private List<Patient_Contact_Name_Family_Extension> extension;

}
