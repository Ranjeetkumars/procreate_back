package com.pro.model;

import lombok.Data;

@Data
public class BlogDoctor {

	private int id;
	private String name;
	
}
