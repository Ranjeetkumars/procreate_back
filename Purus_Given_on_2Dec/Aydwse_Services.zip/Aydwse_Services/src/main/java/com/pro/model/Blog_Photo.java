package com.pro.model;

import lombok.Data;

@Data
public class Blog_Photo {
	private String contentType;
	private String url;

}
