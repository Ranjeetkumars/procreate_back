package com.pro.model;

import lombok.Data;

@Data
public class CallerType 
{
	
	private String id;
	private String name;
	
}
