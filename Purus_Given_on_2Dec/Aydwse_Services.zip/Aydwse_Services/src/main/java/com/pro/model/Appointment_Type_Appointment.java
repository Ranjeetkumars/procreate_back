package com.pro.model;

import lombok.Data;

@Data
public class Appointment_Type_Appointment 

{
	private int id;
	private String type;
	
	
	
}
