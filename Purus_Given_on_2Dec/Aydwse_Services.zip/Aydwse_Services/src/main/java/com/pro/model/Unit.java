package com.pro.model;

import lombok.Data;

@Data
public class Unit {
	private String id;
	private String symbol;
	private String symbol_img;

}
