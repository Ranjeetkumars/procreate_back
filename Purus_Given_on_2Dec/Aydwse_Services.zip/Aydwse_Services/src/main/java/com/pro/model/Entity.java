package com.pro.model;

import lombok.Data;

@Data
public class Entity
{
	private String type;
	private int id;
	private String name;

}
