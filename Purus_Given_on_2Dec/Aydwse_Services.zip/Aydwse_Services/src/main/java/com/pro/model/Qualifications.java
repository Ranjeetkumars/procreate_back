package com.pro.model;


import lombok.Data;

@Data
public class Qualifications {
	private String  id;
	private String name;
}
