package com.pro.model;

import java.util.List;

import lombok.Data;

@Data
public class Patient_Type {
	
	private List<Patient_Coding> coding;

}
