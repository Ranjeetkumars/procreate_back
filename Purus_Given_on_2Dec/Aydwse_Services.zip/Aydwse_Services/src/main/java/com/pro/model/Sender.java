package com.pro.model;

import lombok.Data;

@Data
public class Sender 
{
	private int id;
	private Sender_Type type;

}
