package com.pro.model;

import lombok.Data;

@Data
public class Notifi_Doctor 
{

	private int id;
	private String name;
	
	
}
