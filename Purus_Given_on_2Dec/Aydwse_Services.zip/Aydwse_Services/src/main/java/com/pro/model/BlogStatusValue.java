package com.pro.model;

import lombok.Data;

@Data
public class BlogStatusValue {

	private int id;
	private String name;
	
	
}
