package com.pro.model;

import lombok.Data;

@Data
public class Organizations 
{
	private int id;
	private String name;


}
