package com.pro.model;

import lombok.Data;

@Data
public class Specialization {
	private String  id;
	private String name;
}
