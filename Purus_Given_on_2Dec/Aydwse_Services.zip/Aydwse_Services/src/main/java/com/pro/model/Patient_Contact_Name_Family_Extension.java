package com.pro.model;


import lombok.Data;

@Data
public class Patient_Contact_Name_Family_Extension
{
	private String url;
	
	private String valueString;
	
	
}
