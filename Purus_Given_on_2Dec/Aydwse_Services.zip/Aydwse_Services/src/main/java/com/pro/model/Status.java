package com.pro.model;

import lombok.Data;

@Data
public class Status
{
	private Status_Value  value;
	private String updated_at;

}
