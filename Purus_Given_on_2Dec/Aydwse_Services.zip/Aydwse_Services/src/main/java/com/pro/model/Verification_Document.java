package com.pro.model;

import lombok.Data;

@Data

public class Verification_Document 
{
private Verification_Type  type;

private String document_img;

}
