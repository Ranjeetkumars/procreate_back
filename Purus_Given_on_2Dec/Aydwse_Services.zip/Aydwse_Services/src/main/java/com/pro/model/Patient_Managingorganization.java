package com.pro.model;

import lombok.Data;

@Data
public class Patient_Managingorganization {
	
	private String reference;

}
