package com.pro.model;

import lombok.Data;

@Data
public class Receiver_Type 
{
	private int id;
	private String name;
}
