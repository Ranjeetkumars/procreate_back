package com.pro.model;

import lombok.Data;

@Data
public class Verification_Type 
{
	private int id;
	private String name;


}
