package com.pro.model;

import lombok.Data;

@Data
public class DoctorBlogCommentLikes {

	private Blog_Liker liker;
	private String created_at;
	
}
