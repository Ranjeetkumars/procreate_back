package com.pro.model;

import lombok.Data;

@Data
public class Receiver
{
	private int id;
	private Receiver_Type type;

}
