package com.pro.model;

import lombok.Data;

@Data
public class BlogStatus {
	
	private BlogStatusValue value;
	private String updated_at;

}
