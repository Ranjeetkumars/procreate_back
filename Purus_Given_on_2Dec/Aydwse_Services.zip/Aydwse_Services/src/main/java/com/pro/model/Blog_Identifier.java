package com.pro.model;

import lombok.Data;

@Data
public class Blog_Identifier {
	private String use;
	private Identifer_Type type;
	private String system;
	private String value;

}
