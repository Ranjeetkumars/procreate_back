package com.pro.model;

import lombok.Data;

@Data
public class Doc_Type 
{
	private int id;
	private String name;

}
