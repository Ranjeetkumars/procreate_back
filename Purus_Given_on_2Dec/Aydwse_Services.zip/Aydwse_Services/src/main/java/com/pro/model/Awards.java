package com.pro.model;

import lombok.Data;

@Data
public class Awards {
private String name;
private String attachment;


}
