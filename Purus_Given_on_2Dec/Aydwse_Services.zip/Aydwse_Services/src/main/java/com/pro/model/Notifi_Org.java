package com.pro.model;

import lombok.Data;

@Data
public class Notifi_Org {

	private int id;
	private String type;
	private String name;
}
