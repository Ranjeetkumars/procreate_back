package com.pro.model;

import lombok.Data;

@Data
public class CreatorFAQ 
{
	private String id;
	private String name;
	private CreatorType type;

}
