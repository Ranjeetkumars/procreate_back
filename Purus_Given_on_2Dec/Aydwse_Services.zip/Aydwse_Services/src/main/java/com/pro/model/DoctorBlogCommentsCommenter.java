package com.pro.model;

import lombok.Data;

@Data
public class DoctorBlogCommentsCommenter {
	
	private int id;
	private  String name;
	private  String img;
	

}
