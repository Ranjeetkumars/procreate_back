package com.pro.model;

import lombok.Data;

@Data
public class Patient_Coding {
	
	private String system;
	private String code;

}
