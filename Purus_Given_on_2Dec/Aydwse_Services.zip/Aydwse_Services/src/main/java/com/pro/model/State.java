package com.pro.model;


import lombok.Data;

@Data
public class State {
	private String  id;
	private String name;
}
