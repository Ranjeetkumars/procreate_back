package com.pro.model;


import lombok.Data;

@Data
public class Roles {
	private String  id;
	private String name;
}
