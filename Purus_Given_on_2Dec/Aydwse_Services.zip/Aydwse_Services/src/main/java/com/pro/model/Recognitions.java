package com.pro.model;

import lombok.Data;

@Data
public class Recognitions {
	private String name;
	private String attachment;
}
