package com.pro.model;

import lombok.Data;

@Data
public class Patient_Address_Period {

	private String start;
	
	
	
}
