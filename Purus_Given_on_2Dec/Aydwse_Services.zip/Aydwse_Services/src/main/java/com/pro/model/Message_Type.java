package com.pro.model;

import lombok.Data;

@Data
public class Message_Type 
{
	private int id;
    private String name;
}
