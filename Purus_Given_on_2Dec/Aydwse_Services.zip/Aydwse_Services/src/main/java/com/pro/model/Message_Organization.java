package com.pro.model;

import lombok.Data;

@Data
public class Message_Organization 
{
private int id;
private String type;
private String name;
}
