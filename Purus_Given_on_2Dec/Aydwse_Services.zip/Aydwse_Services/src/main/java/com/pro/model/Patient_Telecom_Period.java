package com.pro.model;

import lombok.Data;

@Data
public class Patient_Telecom_Period {
	
	private String end ;

}
