package com.pro.model;

import java.util.List;

import lombok.Data;

@Data
public class Blog_Name 
{
	private String family;
	private Blog_family _family;
	private List<String> given;

}
