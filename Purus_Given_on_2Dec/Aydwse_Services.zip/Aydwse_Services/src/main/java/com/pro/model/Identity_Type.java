package com.pro.model;

import lombok.Data;

@Data
public class Identity_Type
{
	private int id;
	private String name;


}
