package com.pro.model;

import lombok.Data;

@Data
public class Patient_Text
{
	
  private String status;
  private String div;
  
}
