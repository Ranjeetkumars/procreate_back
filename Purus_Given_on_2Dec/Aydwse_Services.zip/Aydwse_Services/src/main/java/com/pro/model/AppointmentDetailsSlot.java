package com.pro.model;

import lombok.Data;

@Data
public class AppointmentDetailsSlot
{
private String id;
private String start_time;
private String end_time;
}
