package com.pro.model;

import lombok.Data;

@Data
public class Doctor
{
	private int id;
	private String name;
}
