package com.pro.model;

import lombok.Data;

@Data
public class Status_Value 
{
	private int id;
	private String name;

}
