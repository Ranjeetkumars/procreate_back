package com.pro.model;

import lombok.Data;

@Data
public class DoctorBlogViewsViewer {

	private int id;
	private String name;
	private String img;
}
