package com.pro.model;

import lombok.Data;

@Data
public class Patient_Birthdate_Extension {
	
	private String url;
	private String valueDateTime;
	

}
