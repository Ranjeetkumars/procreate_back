package com.pro.model;

import java.util.List;

import lombok.Data;

@Data
public class Blog_Relationship 
{
	
private List<Blog_Coding>coding;
}
