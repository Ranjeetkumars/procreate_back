package com.pro.model;

import lombok.Data;

@Data
public class Verifier 
{
	private int id;
	private String name;
	private String verified_at;
}
