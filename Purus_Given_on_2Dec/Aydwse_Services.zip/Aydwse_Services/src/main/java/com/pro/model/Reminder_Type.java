package com.pro.model;

import lombok.Data;

@Data
public class Reminder_Type 
{
	private int id;
	private String value;
}
