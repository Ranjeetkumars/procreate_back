package com.pro.model;

import lombok.Data;

@Data
public class Notifi_Type {
	
	private int id;
	private String value;

}
