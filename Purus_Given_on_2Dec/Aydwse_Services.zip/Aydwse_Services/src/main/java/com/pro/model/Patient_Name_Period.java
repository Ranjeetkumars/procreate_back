package com.pro.model;

import lombok.Data;

@Data
public class Patient_Name_Period 
{
	
	private String end;
	

}
