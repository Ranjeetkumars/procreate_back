package com.pro.model;

import lombok.Data;

@Data
public class Blog_Telecom 
{
	
private String system;
private String value;
}
