package com.pro.model;

import lombok.Data;

@Data
public class Notifi_Inter
{

	private int id;
	private Notifi_Type type;
	private Notifi_Doctor doctor;
	
}
