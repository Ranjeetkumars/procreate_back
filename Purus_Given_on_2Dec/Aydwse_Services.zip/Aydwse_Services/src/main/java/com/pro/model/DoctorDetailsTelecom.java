package com.pro.model;

import lombok.Data;

@Data
public class DoctorDetailsTelecom {

	private String system;
	private String value;
	private String use;
}
