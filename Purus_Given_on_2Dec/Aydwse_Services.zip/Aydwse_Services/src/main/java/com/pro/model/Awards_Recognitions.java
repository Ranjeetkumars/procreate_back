package com.pro.model;

import java.util.List;

import lombok.Data;

@Data
public class Awards_Recognitions {
	private List<Awards> awards;
	private List<Recognitions> recognitions;
}
