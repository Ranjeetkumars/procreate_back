package com.pro.model;

import lombok.Data;

@Data
public class Slots {
	private String start_time;
	private String end_time;

}
