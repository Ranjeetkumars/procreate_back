package com.pro.model;

import lombok.Data;

@Data
public class DoctorBlogViews 
{

	private DoctorBlogViewsViewer viewer;
	private String created_at;
	
	
}
