package com.pro.model;

import lombok.Data;

@Data
public class Doctor_Appointment {

	private int id;
	private String name;

	
	
}
