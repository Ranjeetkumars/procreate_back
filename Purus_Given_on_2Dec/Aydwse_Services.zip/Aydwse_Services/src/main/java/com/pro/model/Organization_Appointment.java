package com.pro.model;

import lombok.Data;

@Data
public class Organization_Appointment {
	private int id;
	private String type;
	private String name;
	


}
