package com.pro.model;

import lombok.Data;

@Data
public class Blog_Patient {
private String reference;
}
