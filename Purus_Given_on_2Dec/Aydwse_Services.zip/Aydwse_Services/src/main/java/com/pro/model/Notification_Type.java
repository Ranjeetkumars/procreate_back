package com.pro.model;

import lombok.Data;

@Data
public class Notification_Type 
{
private int id;
private String name;

	
}
