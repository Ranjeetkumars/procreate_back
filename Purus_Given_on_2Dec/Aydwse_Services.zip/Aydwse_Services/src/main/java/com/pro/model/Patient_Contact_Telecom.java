package com.pro.model;
import lombok.Data;

@Data
public class Patient_Contact_Telecom {
	
	private String system ;
	private String value ;
	

}
