package com.pro.model;

import lombok.Data;

@Data
public class DoctorBlogLikes {

	private DoctorBlogLikeLiker liker;
	private String created_at;
	
}
