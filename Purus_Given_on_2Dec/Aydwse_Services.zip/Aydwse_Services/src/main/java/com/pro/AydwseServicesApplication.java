package com.pro;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AydwseServicesApplication {

	public static void main(String[] args) {
		SpringApplication.run(AydwseServicesApplication.class, args);
	}

}
