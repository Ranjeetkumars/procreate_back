package com.pro.model;

import lombok.Data;

@Data
public class Notifi_Priority {

	private int id;
	private String value;
	
}
