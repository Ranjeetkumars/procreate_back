package com.pro.model;

import lombok.Data;

@Data
public class Reminder_Priority 
{
private int id;
private String value;
}
