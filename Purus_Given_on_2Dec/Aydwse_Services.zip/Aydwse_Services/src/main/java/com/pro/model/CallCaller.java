package com.pro.model;

import lombok.Data;

@Data
public class CallCaller {
	private String ip;
	private String id;
	private CallerType type;

}
