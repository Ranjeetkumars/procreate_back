package com.pro.model;

import lombok.Data;

@Data
public class CallReciver 
{
	private String ip;
	private String id;
	private ReciverType type;
}
