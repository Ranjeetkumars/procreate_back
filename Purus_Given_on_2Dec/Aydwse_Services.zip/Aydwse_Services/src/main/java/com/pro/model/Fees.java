package com.pro.model;


import lombok.Data;

@Data
public class Fees {
private String amount;
private  Unit unit;

}
