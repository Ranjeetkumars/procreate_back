package com.pro.model;

import lombok.Data;

@Data
public class Identifer_Type 
{
private String text;
}
