package com.pro.model;


import lombok.Data;

@Data
public class Profile {
	private Professional_Details professional_details;
	
//	private Consultation_Fees consultation_Fees;
//	private Availability_Schedule availability_Schedule;

}
