package com.pro.model;

import lombok.Data;

@Data
public class Blog_Coding {
	
private String system;
private String code;
}
