package com.pro.model;

import lombok.Data;

@Data
public class Patient_Appointment 
{
	private int id;
	private String name;

}
