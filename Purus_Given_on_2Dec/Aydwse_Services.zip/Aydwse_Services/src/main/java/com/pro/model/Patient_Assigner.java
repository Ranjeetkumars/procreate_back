package com.pro.model;

import lombok.Data;

@Data
public class Patient_Assigner 
{
	
	private String display;

}
